"""Current version of package pygifsicle"""
__version__ = "1.0.0"