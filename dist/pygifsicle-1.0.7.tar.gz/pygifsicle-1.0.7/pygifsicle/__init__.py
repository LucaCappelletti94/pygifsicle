from support_developer import support_luca
from .pygifsicle import gifsicle, optimize

support_luca("pygifsicle")

__all__ = ["gifsicle", "optimize"]