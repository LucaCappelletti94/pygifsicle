"""Package for gifsicle wrapper."""

from .pygifsicle import gifsicle, optimize

__all__ = ["gifsicle", "optimize"]
